"""hypothesis2

This package contains a variety of helpers for property testing using
hypothesis, e.g. additional decorators, strategies, etc.
"""

from tests.hypothesis2.core import examples
