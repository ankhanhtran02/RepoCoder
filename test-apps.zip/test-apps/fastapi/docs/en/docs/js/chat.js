((window.gitter = {}).chat = {}).options = {
    room: 'tiangolo/fastapi'
};
