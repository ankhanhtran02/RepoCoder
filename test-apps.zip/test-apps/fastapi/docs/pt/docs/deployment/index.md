# Implantação - Introdução

A implantação de uma aplicação **FastAPI** é relativamente simples.

Existem várias maneiras para fazer isso, dependendo do seu caso específico e das ferramentas que você utiliza.

Você verá mais detalhes para se ter em mente e algumas das técnicas para a implantação nas próximas seções.
