!!! warning
    The current page still doesn't have a translation for this language.

    But you can help translating it: [Contributing](https://fastapi.tiangolo.com/contributing/){.internal-link target=_blank}.
